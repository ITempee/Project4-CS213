package com.example.demo1;

public class Resident extends Student{
    private int scholarship;

    //@Override
    public double tuitionDue(int creditEnrolled) {
        double final_tuition = 0;
        final double universityFee = 3268;
        final double partUniversityFee = universityFee* 0.8;
        final double extra_credit_rate = 404;
        final double tuition = 12536;
        if(creditEnrolled>=12){
            final_tuition = tuition +   universityFee;
            if (creditEnrolled>16){
                final_tuition += (creditEnrolled-16) * extra_credit_rate;
            }
        }
        else {
            final_tuition = extra_credit_rate*creditEnrolled + partUniversityFee;
        }
        return final_tuition;
    }

    //@Override
    public boolean isResident() {
        return true;
    }

    public Resident(Profile profile, Major major, int creditCompleted){
        super(profile,major,creditCompleted);
        this.scholarship = scholarship;
    }
    public int getScholarship(){
        return scholarship;
    }
    public void setScholarship(int scholarship){
        this.scholarship = scholarship;
    }
}
