package com.example.demo1;

public class NonResident extends Student{
    //@Override
    public double tuitionDue(int creditEnrolled) {
        double final_tuition = 0;
        final double universityFee = 3268;
        final double partUniversityFee = universityFee* 0.8;
        final double extra_credit_rate = 966;
        final double tuition = 29737;
        if(creditEnrolled>=12){
            final_tuition = tuition +   universityFee;
            if (creditEnrolled>16){
                final_tuition += (creditEnrolled-16) * extra_credit_rate;
            }
        }
        else {
            final_tuition = extra_credit_rate*creditEnrolled + partUniversityFee;
        }
        return final_tuition;
    }
    public double abroadTuition(){
        final double universityFee = 3268;
        final double partUniversityFee = universityFee* 0.8;
        return partUniversityFee;
    }

    //@Override
    public boolean isResident() {
        return false;
    }

    public NonResident(Profile profile, Major major, int creditCompleted) {
        super(profile,major,creditCompleted);
    }
}
