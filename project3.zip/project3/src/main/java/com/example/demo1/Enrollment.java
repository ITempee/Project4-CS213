package com.example.demo1;

public class Enrollment {
    private EnrollStudent[] enrollStudents;
    private int size;

    /**
     * Constructor for the Enrollment object.
     *
     * //@param enrollStudents Array of EnrollStudent objects, initialize with capacity of 10 students
     * //@param size Number of students in EnrollStudent object array.
     */

    public Enrollment() {
        this.enrollStudents = new EnrollStudent[10];
        this.size = 0;
    }

    /**
     * Adds a student object to the array
     *
     * //@param enrollStudents Student object being added to EnrollStudent array.
     *  When full, array will be doubled in size.
     */

    public void add(EnrollStudent enrollStudent) {
        if (this.size == this.enrollStudents.length) {
            EnrollStudent[] newEnrollStudents = new EnrollStudent[this.enrollStudents.length * 2];
            for (int i = 0; i < this.size; i++) {
                newEnrollStudents[i] = this.enrollStudents[i];
            }
            this.enrollStudents = newEnrollStudents;
        }
        this.enrollStudents[this.size] = enrollStudent;
        this.size++;
    }

    /**
     * Removes student object from the student array.
     *
     * //@param enrollStudents Student intended to be removed.
     */

    public void remove(EnrollStudent enrollStudent) {
        for (int i = 0; i < this.size; i++) {
            if (this.enrollStudents[i].getProfile().equals(enrollStudent.getProfile())) {
                this.enrollStudents[i] = this.enrollStudents[this.size - 1];
                this.enrollStudents[this.size - 1] = null;
                this.size--;
                return;
            }
        }
    }

    /**
     * This method checks to see if the student array contains a specified student.
     *
     * //@param student student meant to be searched for.
     * @return True or False based on if student was found or not.
     */

    public boolean contains(EnrollStudent enrollStudent) {
        for (int i = 0; i < this.size; i++) {
            if (this.enrollStudents[i].getProfile().equals(enrollStudent.getProfile())) {
                return true;
            }
        }
        return false;
    }
    public int find(EnrollStudent enrollStudent){
        for (int i = 0; i < this.size; i++) {
            if (this.enrollStudents[i].getProfile().equals(enrollStudent.getProfile())) {
                return i;
            }
        }
        return -1;
    }
    public int find_e(Profile profile){
        for (int i = 0; i < this.size; i++) {
            if (this.enrollStudents[i].getProfile().equals(profile)) {
                return i;
            }
        }
        return -1;
    }
    public void updateCredits(EnrollStudent enrollStudent, int credits){
        if(contains(enrollStudent)){
            int found = find(enrollStudent);
            enrollStudents[found].setCreditsEnrolled(credits);
        }
    }
    /**
     * prints student array as is
     */
    public String print() {
        String output = "";
        for (int i = 0; i < this.size; i++) {
            output += this.enrollStudents[i].getProfile().toString() + " " + this.enrollStudents[i].getCreditsEnrolled() + "\n";
            System.out.println(this.enrollStudents[i].getProfile().toString() + " " + this.enrollStudents[i].getCreditsEnrolled());
        }
        return output;
    }
    public EnrollStudent[] getEnrollStudents(){
        return enrollStudents;
    }

    public int getSize() {
        return size;
    }
}