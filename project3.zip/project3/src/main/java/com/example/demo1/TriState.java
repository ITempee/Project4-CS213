package com.example.demo1;

public class TriState extends NonResident {
    private String state;
    public TriState(Profile profile, Major major, int creditCompleted) {
        super(profile, major, creditCompleted);
        this.state = state;
    }
    public String getState(){
        return state;
    }
    public void setState(String state){
        this.state = state;
    }
}
