package com.example.demo1;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;

import java.text.DecimalFormat;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.StringTokenizer;

import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.ToggleGroup;

/**
 *  The HelloController class houses the GUI interface replacing Tuition Manager from Project 2.
 *  It contains all methods and constructers used to make the program run.
 *  Author Adam Shaikh, Moises Manrique and David Joachim
 */
public class TuitionManagerController {
    public static final int input_size = 5;
    public static final int file_size = 6;
    public static final int roster_len = 3;
    public static final int starting_amount = 0;
    String[] userData = new String[input_size];
    String[] file_input = new String[file_size];
    Student[] student_roster = new Student[roster_len];
    //EnrollStudent[] enrollStudents = new EnrollStudent[10];
    Enrollment enrollment = new Enrollment();
    Roster roster = new Roster(student_roster, starting_amount);

    /**
     * Assigns a major based on major code.
     *
     * @param major Name of major code.
     * @return object of type Major with a specific major.
     */
    public Major assign_Major(String major) {
        if (major.equalsIgnoreCase("EE")) {
            Major new_major = Major.EE;
            return new_major;
        } else if (major.equalsIgnoreCase("CS")) {
            Major new_major = Major.CS;
            return new_major;
        } else if (major.equalsIgnoreCase("MATH")) {
            Major new_major = Major.MATH;
            return new_major;
        } else if (major.equalsIgnoreCase("BAIT")) {
            Major new_major = Major.BAIT;
            return new_major;
        } else if (major.equalsIgnoreCase("ITI")) {
            Major new_major = Major.ITI;
            return new_major;
        } else {
            return null;
        }
    }

    /**
     * Method Loads text from input file and creates student objects out of them
     * @throws FileNotFoundException
     */

    public void loadStudent(String pathname) throws FileNotFoundException {
        File file = new File(pathname);
        Scanner scan = new Scanner(file);
        while (scan.hasNextLine()) {
            String total_str = scan.nextLine();
            StringTokenizer st = new StringTokenizer(total_str, ",");
            int amountOfInputs = st.countTokens();
            String first = st.nextToken();
            if (amountOfInputs == 6) {
                if (first.equals("R")) {
                    userData = read_info(st);
                    Resident res = create_resident(userData[0], userData[1], userData[2], userData[3], userData[4]);
                    add_student(res);
                }
                if (first.equals("N")) {
                    userData = read_info(st);
                    NonResident nonResident = create_nonResident(userData[0], userData[1], userData[2], userData[3], userData[4]);
                    add_student(nonResident);
                }
                if (first.equals("I")) {
                    userData = read_info(st);
                    International international = create_international(userData[0], userData[1], userData[2], userData[3], userData[4], "false");
                    add_student(international);
                }
            }
            if (amountOfInputs == 7) {
                if (first.equals("I")) {
                    file_input = read_extra(st);
                    International international = create_international(file_input[0], file_input[1], file_input[2], file_input[3], file_input[4], file_input[5]);
                    add_student(international);
                }
                if (first.equals("T")) {
                    file_input = read_extra(st);
                    TriState triState = create_tri(file_input[0], file_input[1], file_input[2], file_input[3], file_input[4], file_input[5]);
                    add_student(triState);
                }
            }
        }
        result.setText("Students loaded to the roster.");
    }

    /**
     * Method creates and adds a resident attribute to specified students
     * @param first_name
     * @param last_name
     * @param date_of_birth
     * @param student_major
     * @param student_cred
     * @return
     */
    public Resident create_resident(String first_name, String last_name, String date_of_birth, String student_major, String student_cred) {
        int illegal_cred = -1;
        Date date = new Date(date_of_birth);
        Major major = assign_Major(student_major);
        if (date.isValid() && major != null) {
            Profile profile = new Profile(first_name, last_name, date);
            try {
                int credits = Integer.parseInt(student_cred);
                if (credits > illegal_cred) {
                    Date curr_date = new Date();
                    if (old_enough(curr_date, date)) {
                        Resident resident = new Resident(profile, major, credits);
                        resident.setScholarship(0);
                        return resident;
                    }
                } else {
                    result.setText("Credits completed invalid: can not be negative!");
                    return null;
                }
            } catch (NumberFormatException e) {
                result.setText("Credits completed invalid: not an integer!");
            }
        } else if (date.isValid() == false) {
            result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
            if (major == null) {
                result.setText("Major code invalid: " + student_major);
            }
        }
        if (major == null) {
            result.setText("Major code invalid: " + student_major);
        }
        return null;
    }

    /**
     * Method creates and adds non resident attribute to specified students
     * @param first_name
     * @param last_name
     * @param date_of_birth
     * @param student_major
     * @param student_cred
     * @return
     */
    public NonResident create_nonResident(String first_name, String last_name, String date_of_birth, String student_major, String student_cred) {
        int illegal_cred = -1;
        Date date = new Date(date_of_birth);
        Major major = assign_Major(student_major);
        if (date.isValid() && major != null) {
            Profile profile = new Profile(first_name, last_name, date);
            try {
                int credits = Integer.parseInt(student_cred);
                if (credits > illegal_cred) {
                    Date curr_date = new Date();
                    if (old_enough(curr_date, date)) {
                        NonResident nonResident = new NonResident(profile, major, credits);
                        return nonResident;
                    }
                } else {
                    result.setText("Credits completed invalid: can not be negative!");
                    return null;
                }
            } catch (NumberFormatException e) {
                result.setText("Credits completed invalid: not an integer!");
            }
        } else if (date.isValid() == false) {
            result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
            if (major == null) {
                result.setText("Major code invalid: " + student_major);
            }
        }
        if (major == null) {
            result.setText("Major code invalid: " + student_major);
        }
        return null;
    }

    /**
     * Method creates and adds internation attribute to specified students
     * @param first_name
     * @param last_name
     * @param date_of_birth
     * @param student_major
     * @param student_cred
     * @param bool
     * @return
     */
    public International create_international(String first_name, String last_name, String date_of_birth, String student_major, String student_cred, String bool) {
        int illegal_cred = -1;
        Date date = new Date(date_of_birth);
        Major major = assign_Major(student_major);
        if (date.isValid() && major != null) {
            Profile profile = new Profile(first_name, last_name, date);
            try {
                int credits = Integer.parseInt(student_cred);
                if (credits > illegal_cred) {
                    Date curr_date = new Date();
                    if (old_enough(curr_date, date)) {
                        International international = new International(profile, major, credits);
                        if (bool.equals("false")) {
                            international.setStudyAbroad(false);
                        } else {
                            international.setStudyAbroad(true);
                        }
                        return international;
                    }
                } else {
                    result.setText("Credits completed invalid: can not be negative!");
                    return null;
                }
            } catch (NumberFormatException e) {
                result.setText("Credits completed invalid: not an integer!");
            }
        } else if (date.isValid() == false) {
            result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
            if (major == null) {
                result.setText("Major code invalid: " + student_major);
            }
        }
        if (major == null) {
            result.setText("Major code invalid: " + student_major);
        }
        return null;
    }

    /**
     * Method creates and adds tri state attribute to specified students
     * @param first_name
     * @param last_name
     * @param date_of_birth
     * @param student_major
     * @param student_cred
     * @param state
     * @return
     */
    public TriState create_tri(String first_name, String last_name, String date_of_birth, String student_major, String student_cred, String state) {
        int illegal_cred = -1;
        Date date = new Date(date_of_birth);
        Major major = assign_Major(student_major);
        if (date.isValid() && major != null) {
            Profile profile = new Profile(first_name, last_name, date);
            try {
                int credits = Integer.parseInt(student_cred);
                if (credits > illegal_cred) {
                    Date curr_date = new Date();
                    if (old_enough(curr_date, date)) {
                        TriState triState = new TriState(profile, major, credits);
                        triState.setState(state);
                        return triState;
                    }
                } else {
                    result.setText("Credits completed invalid: can not be negative!");
                    return null;
                }
            } catch (NumberFormatException e) {
                result.setText("Credits completed invalid: not an integer!");
            }
        } else if (date.isValid() == false) {
            result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
            if (major == null) {
                result.setText("Major code invalid: " + student_major);
            }
        }
        if (major == null) {
            result.setText("Major code invalid: " + student_major);
        }
        return null;
    }

    /**
     * Method takes a given profile, checks to see if theyre eligible for a scholarship, then applies scholarship or returns
     * @param profile
     * @param scholarship
     */
    public void awardScholarship(Profile profile, int scholarship) {
        int i = enrollment.find_e(profile);
        if(i != 1) {
            if (student_roster[i].isResident()) {
                Resident resident = (Resident) student_roster[i];
                resident.setScholarship(scholarship);
                result.setText("New scholarship amount is: " + ((Resident) student_roster[i]).getScholarship());
            }
        }
        else
            result.setText("Not Enrolled");
    }

    /**
     * This method checks to see if student is 16 or older.
     *
     * @param curr_date Today's date in the form of a Date object
     * @param date      Date object that contains the date of birth of a specific student
     * @return True or False based on if student is atleast 16.
     */

    public boolean old_enough(Date curr_date, Date date) {
        int age_target = 16;
        if (curr_date.get_year() - date.get_year() > age_target) {
            return true;
        } else if (curr_date.get_year() - date.get_year() == age_target) {
            if (curr_date.get_month() > date.get_month()) {
                return true;
            } else if (curr_date.get_month() < date.get_month()) {
                result.setText("DOB invalid: " + date.toString() + " younger than 16 years old.");
                return false;
            } else {
                if (curr_date.get_day() > date.get_day()) {

                } else if (curr_date.get_day() < date.get_day()) {
                    result.setText("DOB invalid: " + date.toString() + " younger than 16 years old.");
                    return false;
                } else {
                    result.setText("They are old enough");
                    return true;
                }
            }
        }
        result.setText("DOB invalid: " + date.toString() + " younger than 16 years old.");
        return false;
    }

    /**
     * Assigns major object based on name of school.
     *
     * @param target Name of school.
     * @return Specified major object of type Major.
     */
    public Major retrieve_majors(String target) {
        if (target.equalsIgnoreCase("SAS")) {
            Major major = Major.CS;
            return major;
        } else if (target.equalsIgnoreCase("SOE")) {
            Major major = Major.EE;
            return major;
        } else if (target.equalsIgnoreCase("SC&I")) {
            Major major = Major.ITI;
            return major;
        } else if (target.equalsIgnoreCase("RBS")) {
            Major major = Major.BAIT;
            return major;
        } else {
            return null;
        }
    }

    /**
     * Prints out students of a specific major.
     *
     * @param target Target major.
     */
    public String print_major(String target) {
        String output = "";
        int match = 0;
        Major target_major = retrieve_majors(target);
        if (target_major != null) {
            if (target_major == Major.CS) {
                Student[] temp_roster = roster.getRoster();
                for (int i = 0; i < roster.getSize(); i++) {
                    if (temp_roster[i].getMajor().compareTo(target_major) == match || temp_roster[i].getMajor().compareTo(Major.MATH) == match) {
                        output += temp_roster[i].toString() + "\n";
                        result.setText(temp_roster[i].toString());
                    }
                }
            } else {
                Student[] temp_roster = roster.getRoster();
                for (int i = 0; i < roster.getSize(); i++) {
                    if (temp_roster[i].getMajor().compareTo(target_major) == match) {
                        output += temp_roster[i].toString() + "\n";
                        result.setText(temp_roster[i].toString());
                    }
                }
            }
        } else {
            output += "School doesn't exist: " + target + "\n";
            result.setText("School doesn't exist: " + target);
        }
        return output;
    }

    /**
     * Checks to see if Student has a valid major, credit, and date of birth. Then creates the Student object.
     *
     * @param first_name    First name of the student.
     * @param last_name     Last name of the student
     * @param date_of_birth date of birth of the student.
     * @param student_major major of the student
     * @param student_cred  credits of the student
     * @return Constructed student object.
     */
    public Student create_student(String first_name, String last_name, String date_of_birth, String student_major, String student_cred) {
        int illegal_cred = -1;
        Date date = new Date(date_of_birth);
        Major major = assign_Major(student_major);
        if (date.isValid() && major != null) {
            Profile profile = new Profile(first_name, last_name, date);
            try {
                int credits = Integer.parseInt(student_cred);
                if (credits > illegal_cred) {
                    Date curr_date = new Date();
                    if (old_enough(curr_date, date)) {
                        Student student = new Student(profile, major, credits) {
                            @Override
                            public double tuitionDue(int creditEnrolled) {
                                return 0;
                            }

                            @Override
                            public boolean isResident() {
                                return false;
                            }
                        };
                        return student;
                    }
                } else {
                    result.setText("Credits completed invalid: can not be negative!");
                    return null;
                }
            } catch (NumberFormatException e) {
                result.setText("Credits completed invalid: not an integer!");
            }
        } else if (date.isValid() == false) {
            result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
            if (major == null) {
                result.setText("Major code invalid: " + student_major);
            }
        }
        if (major == null) {
            result.setText("Major code invalid: " + student_major);
        }
        return null;
    }

    /**
     * Reads tokenized string into an array of inputs.
     *
     * @param st1 Tokenized string of user inputs.
     * @return array of user inputs in the form of a string array.
     */
    public String[] read_three(StringTokenizer st1) {
        if (st1.countTokens() < 3) {
            result.setText("Missing data in line command.");
            userData[0] = "Fail";
            return userData;
        } else {
            for (int i = 0; i < userData.length; i++) {
                if (st1.hasMoreElements()) {
                    userData[i] = st1.nextToken();
                }
            }
        }
        return userData;
    }

    /**
     * Method checks for error with inputs, citing the amount of given information
     * @param st1
     * @return
     */
    public String[] read_less(StringTokenizer st1) {
        if (st1.countTokens() < 4) {
            result.setText("Missing data in line command.");
            userData[0] = "Fail";
            return userData;
        } else {
            for (int i = 0; i < userData.length; i++) {
                if (st1.hasMoreElements()) {
                    userData[i] = st1.nextToken();
                }
            }
        }
        return userData;
    }

    /**
     * Method does a double check for correct inputs, returns with error if specified length is not met
     * @param st1
     * @return
     */
    public String[] read_info(StringTokenizer st1) {
        if (st1.countTokens() < 5) {
            result.setText("Missing data in line command.");
            userData[0] = "Fail";
            return userData;
        } else {
            for (int i = 0; i < userData.length; i++) {
                if (st1.hasMoreElements()) {
                    userData[i] = st1.nextToken();
                }
            }
        }
        return userData;
    }

    /**
     * Method is an extra measure to catch exceptions with file length
     * @param st1
     * @return
     */
    public String[] read_extra(StringTokenizer st1) {
        for (int i = 0; i < file_input.length; i++) {
            try {
                file_input[i] = st1.nextToken();
                //result.setText((file_input[i]));
            } catch (NoSuchElementException e) {
                break;
            }
        }
        return file_input;
    }

    /**
     * Adds student to Roster object and resizes based on if there is enough space.
     *
     * @param newStudent Target student intended to be added to student array.
     */
    public String add_student(Student newStudent) {
        String output = null;
        if (newStudent != null) {
            if (roster.contains(newStudent)) {
                output = newStudent.getProfile().toString() + " is already in the roster" +"\n";
                result.setText(newStudent.getProfile().toString() + " is already in the roster");
                return output;
            }
            if (roster.add(newStudent) == false) {
                roster.grow();
                roster.add(newStudent);
            }
            output = (newStudent.getProfile().toString() + " added to the roster") +"\n";
            result.setText(newStudent.getProfile().toString() + " added to the roster");
            return output;
        }
        return "false";
    }

    /**
     * Enroll student method enrolls students on the roster given they have the correct amount of credits for
     * their given attributes
     * @param newStudent
     */
    public void enroll_student(EnrollStudent newStudent) {
        if (newStudent != null) {
            int found;
            if ((newStudent.getCreditsEnrolled() > 24) || newStudent.getCreditsEnrolled() < 3) {
                found = roster.find(newStudent.getProfile());
                if (found != -1) {
                    Student[] tempros = roster.getRoster();
                    if (!tempros[found].isResident()) {
                        result.setText("(Non-Resident) " + newStudent.getCreditsEnrolled() + ": invalid credit hours.");
                        return;
                    } else {
                        result.setText("(Resident) " + newStudent.getCreditsEnrolled() + ": invalid credit hours.");
                        return;
                    }
                }
            }
            if (enrollment.contains(newStudent)) {
                enrollment.updateCredits(newStudent, newStudent.getCreditsEnrolled());
                result.setText(newStudent.getProfile().toString() + " is already in the roster");
            } else {
                enrollment.add(newStudent);
                result.setText(newStudent.getProfile().toString() + " enrolled");
            }
        }
    }

    /**
     * Print tuition method prints the cost of tuition for a specified student or all of those enrolled
     * @return
     */
    public String print_tuition() {
        String output = "";
        EnrollStudent[] tempEnr = enrollment.getEnrollStudents();
        Student[] tempRos = roster.getRoster();
        int size = enrollment.getSize();
        result.setText("The size of the Enrollment[] is :" + size);
        DecimalFormat df = new DecimalFormat("0.00");
        for (int i = 0; i < size; i++) {
            if (roster.find(tempEnr[i].getProfile()) != -1) {
                int found = roster.find(tempEnr[i].getProfile());
                boolean resident = tempRos[found].isResident();
                if (resident) {
                    Resident currRes = (Resident) tempRos[found];
                    output += tempEnr[i].getProfile().toString() + "(Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currRes.tuitionDue(tempEnr[i].getCreditsEnrolled()) - currRes.getScholarship()) + "\n";
                    result.setText(tempEnr[i].getProfile().toString() + "(Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currRes.tuitionDue(tempEnr[i].getCreditsEnrolled()) - currRes.getScholarship()));
                } else {
                    if (tempRos[found] instanceof TriState) {
                        int discount = 0;
                        TriState currTri = (TriState) tempRos[found];
                        if (currTri.getState().equals("NY")) {
                            discount = 4000;
                        } else {
                            discount = 5000;
                        }
                        output += tempEnr[i].getProfile().toString() + " (Non-Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currTri.tuitionDue(tempEnr[i].getCreditsEnrolled()) - discount) + "\n";
                                result.setText(tempEnr[i].getProfile().toString() + " (Non-Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currTri.tuitionDue(tempEnr[i].getCreditsEnrolled()) - discount));
                    } else if (tempRos[found] instanceof International) {
                        International currInt = (International) tempRos[found];
                        if (!currInt.getAbroad()) {
                            output += tempEnr[i].getProfile().toString() + " (Non-Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currInt.tuitionDue(tempEnr[i].getCreditsEnrolled())) +"\n";
                            result.setText(tempEnr[i].getProfile().toString() + " (Non-Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currInt.tuitionDue(tempEnr[i].getCreditsEnrolled())));
                        } else {
                            output += tempEnr[i].getProfile().toString() + " (Non-Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currInt.abroadTuition()) + "\n";
                            result.setText(tempEnr[i].getProfile().toString() + " (Non-Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currInt.abroadTuition()));
                        }
                    } else if (tempRos[found] instanceof NonResident) {
                        NonResident currNon = (NonResident) tempRos[found];
                        output += tempEnr[i].getProfile().toString() + " (Non-Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currNon.tuitionDue(tempEnr[i].getCreditsEnrolled())) + "\n";
                        result.setText(tempEnr[i].getProfile().toString() + " (Non-Resident) enrolled in " + tempEnr[i].getCreditsEnrolled() + " credits: tuition due: " + df.format(currNon.tuitionDue(tempEnr[i].getCreditsEnrolled())));
                    }
                }
            } else {
                output += "Not in Roster" + "\n";
                result.setText("Not in Roster");
            }
        }
        return output;
    }

    /**
     * Semester end method ends the semester, clearing the enrollment and roster
     * @return
     */

    public String semesterEnd() {
        String output = "";
        EnrollStudent[] tempEnr = enrollment.getEnrollStudents();
        Student[] tempRos = roster.getRoster();
        int size = enrollment.getSize();
        for (int i = 0; i < size; i++) {
            if (roster.find(tempEnr[i].getProfile()) != -1) {
                int found = roster.find(tempEnr[i].getProfile());
                Student currStu = tempRos[found];
                currStu.setCreditCompleted(currStu.getCreditCompleted() + tempEnr[i].getCreditsEnrolled());
                output += "New Credits Completed are: " + currStu.getCreditCompleted() + "\n";
                result.setText("New Credits Completed are: " + currStu.getCreditCompleted());
            } else {
                output += "Not in Roster" + "\n";
                result.setText("Not in Roster");
            }
        }
        return output;
    }

    /**
     * Checks to see if the Student array is empty.
     *
     * @return True or False based on if Student array is empty.
     */
    public boolean isEmpty() {
        int empty = 0;
        if (roster.getSize() == empty) {
            result.setText("Student roster is empty!");
            return true;
        }
        return false;
    }

    /**
     * Searches for student and changes student major if student is found in student array
     *
     * @param firstName First name of student.
     * @param lastName  Last name of student.
     * @param date      Date of birth of student.
     * @param major     Major that is meant to be changed to.
     */
    public void search_student(String firstName, String lastName, String date, String major) {
        int match = 0;
        Date student_date = new Date(date);
        Profile student_profile = new Profile(firstName, lastName, student_date);
        Major student_major = assign_Major(major);
        Student[] temp_arr = roster.getRoster();
        if (student_major != null) {
            for (int i = 0; i < roster.getSize(); i++) {
                if (temp_arr[i].getProfile().compareTo(student_profile) == match) {
                    temp_arr[i].setMajor(student_major);
                    result.setText(temp_arr[i].toString());
                }
            }
        } else {
            result.setText("Major code invalid: " + major);
        }
    }
    @FXML
    private TextField input;
    //@FXML
    //private TextField input2;
    @FXML
    private TextField result;
    @FXML
    private Button calculateBtn;
    @FXML
    private Button addBtn;
    @FXML
    private Button printBtn;
    @FXML
    private Button printAllRadio;
    @FXML
    private Button printL;
    @FXML
    private Button printSchoolRadio;
    @FXML
    private Button printStandingRadio;
    @FXML
    private Button printEnrollment;
    @FXML
    private Button printTuition;
    @FXML
    /**
     * This method contains the body of the Gui and its technical innerworks along with the methods previously
     * contained in tuition manager
     */
    public void initialize() {
        int total_input = 5;
        int zero_input = 0; int first_input = 1; int second_input = 2; int third_input =3; int fourth_input = 4; int fifth_input = 5;
        result.setText("Roster Manager running...");
        calculateBtn.setOnAction(event -> {
            String temp = input.getText();
            StringTokenizer st1 = new StringTokenizer(temp, " ");
            if (st1.hasMoreTokens()) {
                int amountOfInputs = st1.countTokens();
                String token = st1.nextToken();
                if (token.equals("AR")) {
                    userData = read_info(st1);
                    if (userData[zero_input] != "Fail") {
                        Resident resident = create_resident(userData[zero_input], userData[first_input], userData[second_input], userData[third_input], userData[fourth_input]);
                        Date date = new Date(userData[second_input]);
                        if (!date.isValid()) {
                            result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
                        } else {
                            if(resident!= null) {
                                String output = add_student(resident);
                                if (output != "false")
                                    result.setText(output);
                            }
                        }
                    }
                    input.clear();
                } else if (token.equals("AN")) {
                    userData = read_info(st1);
                    if (userData[zero_input] != "Fail") {
                        NonResident nonResident = create_nonResident(userData[zero_input], userData[first_input], userData[second_input], userData[third_input], userData[fourth_input]);
                        Date date = new Date(userData[second_input]);
                        Profile profile = new Profile(userData[zero_input], userData[first_input], date);
                        int credits = Integer.parseInt(userData[fourth_input]);
                        if (!date.isValid()) {
                            result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
                        } else {
                            String output = add_student(nonResident);
                            result.setText(output);
                        }
                    }
                    input.clear();
                } else if (token.equals("AT")) {
                    userData = read_info(st1);
                    if (userData[zero_input] != "Fail") {
                        Resident resident = create_resident(userData[zero_input], userData[first_input], userData[second_input], userData[third_input], userData[fourth_input]);
                        Date date = new Date(userData[second_input]);
                        Profile profile = new Profile(userData[zero_input], userData[first_input], date);
                        int credits = Integer.parseInt(userData[fourth_input]);
                        if (!date.isValid()) {
                            result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
                        } else {
                            String output = add_student(resident);
                            result.setText(output);
                        }
                    }
                    input.clear();
                } else if (token.equals("AI")) {
                    userData = read_info(st1);
                    if (userData[zero_input] != "Fail") {
                        if (amountOfInputs == 6) {
                            International international = create_international(userData[zero_input], userData[first_input], userData[second_input], userData[third_input], userData[fourth_input], "false");
                            Date date = new Date(userData[second_input]);
                            if (!date.isValid()) {
                                result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
                            } else {
                                String output = add_student(international);
                                result.setText(output);
                            }
                        } else {
                            file_input = read_extra(st1);
                            International international = create_international(file_input[zero_input], file_input[first_input], file_input[second_input], file_input[third_input], file_input[fourth_input], file_input[fifth_input]);
                            Date date = new Date(userData[second_input]);
                            if (!date.isValid()) {
                                result.setText("DOB invalid: " + date.toString() + " not a valid calendar date!");
                            } else {
                                String output = add_student(international);
                                result.setText(output);
                            }
                        }
                    }
                    input.clear();
                } else if (token.equals("E")) {
                    userData = read_less(st1);
                    Date date = new Date(userData[second_input]);
                    Profile profile = new Profile(userData[zero_input], userData[first_input], date);
                    int credits = Integer.parseInt(userData[third_input]);
                    EnrollStudent enrollStudent = new EnrollStudent(profile, credits);
                    enroll_student(enrollStudent);
                    input.clear();
                } else if (token.equals("D")) {
                    userData = read_three(st1);
                    Date date = new Date(userData[second_input]);
                    Profile profile = new Profile(userData[zero_input], userData[first_input], date);
                    EnrollStudent enrollStudent = new EnrollStudent(profile, 0);
                    enrollment.remove(enrollStudent);
                    result.setText(enrollStudent.getProfile().get_fname() + " " + enrollStudent.getProfile().get_lname() + " Dropped from Enrollment.");
                    input.clear();
                } else if (token.equals("C")) {
                    userData = read_less(st1);
                    search_student(userData[zero_input], userData[first_input], userData[second_input], userData[third_input]);

                    input.clear();
                } else if (token.equals("S")) {
                    userData = read_less(st1);
                    Date date = new Date(userData[second_input]);
                    Profile profile = new Profile(userData[zero_input], userData[first_input], date);
                    int scholarship = Integer.parseInt(userData[third_input]);
                    awardScholarship(profile, scholarship);
                    input.clear();
                }
                else{
                    result.setText(token + " is an invalid command");
                    input.requestFocus();
                }
            }
        });
        addBtn.setOnAction(event -> {
            try {
                loadStudent("studentList.txt");
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
        });
        printBtn.setOnAction(event -> {
            String output = semesterEnd();
            Label label = new Label(output);
            label.setWrapText(true);
            VBox vBox = new VBox(label);
            Scene scene = new Scene(vBox, 300, 200);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
            printBtn.setDisable(true);
            result.setText("Semester End!");
        });
        printAllRadio.setOnAction(event -> {
            String output = roster.print();
            Label label = new Label(output);
            label.setWrapText(true);
            VBox vBox = new VBox(label);
            Scene scene = new Scene(vBox, 300, 200);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        });
        printSchoolRadio.setOnAction(event -> {
            String output = roster.printBySchoolMajor();
            Label label = new Label(output);
            label.setWrapText(true);
            VBox vBox = new VBox(label);
            Scene scene = new Scene(vBox, 300, 200);
            Stage stage = new Stage();
            stage.setTitle("PrintSchool");
            stage.setScene(scene);
            stage.show();
        });
        printStandingRadio.setOnAction(event -> {
            String output = roster.printBySchoolMajor();
            Label label = new Label(output);
            label.setWrapText(true);
            VBox vBox = new VBox(label);
            Scene scene = new Scene(vBox, 300, 200);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        });
        printEnrollment.setOnAction(event -> {
            String output = enrollment.print();
            Label label = new Label(output);
            label.setWrapText(true);
            VBox vBox = new VBox(label);
            Scene scene = new Scene(vBox, 300, 200);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        });
        printTuition.setOnAction(event -> {
            String output = print_tuition();
            Label label = new Label(output);
            label.setWrapText(true);
            VBox vBox = new VBox(label);
            Scene scene = new Scene(vBox, 300, 200);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        });
        printL.setOnAction(event -> {
            String output ="";
            if (!isEmpty()) {
                String finput = input.getText();
                output = print_major(finput);
            }
            Label label = new Label(output);
            label.setWrapText(true);
            VBox vBox = new VBox(label);
            Scene scene = new Scene(vBox, 300, 200);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
        });
    }
}