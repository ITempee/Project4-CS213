package com.example.demo1;

public class EnrollStudent {
    private Profile profile;
    private int creditsEnrolled;
    public EnrollStudent(Profile profile, int creditsEnrolled){
        this.profile = profile;
        this.creditsEnrolled = creditsEnrolled;
    }
    public Profile getProfile(){
        return profile;
    }
    public int getCreditsEnrolled(){
        return creditsEnrolled;
    }
    public void setCreditsEnrolled(int creditsEnrolled){
        this.creditsEnrolled = creditsEnrolled;
    }
}