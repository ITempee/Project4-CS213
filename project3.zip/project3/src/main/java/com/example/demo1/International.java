package com.example.demo1;

public class International extends NonResident{
    private boolean isStudyAbroad;
    public International(Profile profile, Major major, int creditCompleted) {
        super(profile, major, creditCompleted);
        this.isStudyAbroad = isStudyAbroad;
    }
    public boolean getAbroad(){
        return isStudyAbroad;
    }
    public void setStudyAbroad(boolean isStudyAbroad){
        this.isStudyAbroad = isStudyAbroad;
    }
}
